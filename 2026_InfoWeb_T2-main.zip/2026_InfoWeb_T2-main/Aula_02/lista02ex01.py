print("Digite quatro valores inteiros")
a = int(input())
b = int(input())
c = int(input())
d = int(input())

